/* libs */

//= libs/jquery-3.3.1.min.js
//= libs/jquery.fancybox.min.js
//= libs/jquery.maskedinput.min.js
//= libs/slick.min.js
//= libs/jquery-ui.min.js

/* my scripts */

//= partials/main.js
